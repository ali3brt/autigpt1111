# elements-layout-user-menu

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test elements-layout-user-menu` to execute the unit tests.
