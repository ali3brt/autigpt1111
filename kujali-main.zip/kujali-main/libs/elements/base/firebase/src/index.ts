export * from './lib/firebase-configuration.module';
