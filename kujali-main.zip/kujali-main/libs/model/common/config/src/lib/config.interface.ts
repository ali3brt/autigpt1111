export interface IConfig {}
