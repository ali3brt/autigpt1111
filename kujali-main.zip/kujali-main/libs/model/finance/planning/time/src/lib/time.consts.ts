/**
 * 
 */
export const MONTHS = [ { name: 'FIN.TM.JAN', month: 1, slug: 'jan' }, { name: 'FIN.TM.FEB', month: 2, slug: 'feb' },
                        { name: 'FIN.TM.MAR', month: 3, slug: 'mar' }, { name: 'FIN.TM.APR', month: 4, slug: 'apr' },
                        { name: 'FIN.TM.MAY', month: 5, slug: 'may' }, { name: 'FIN.TM.JUN', month: 6, slug: 'jun' },
                        { name: 'FIN.TM.JUL', month: 7, slug: 'jul' }, { name: 'FIN.TM.AUG', month: 8, slug: 'aug' },
                        { name: 'FIN.TM.SEP', month: 9, slug: 'sep' }, { name: 'FIN.TM.OCT', month: 10, slug: 'oct' },
                        { name: 'FIN.TM.NOV', month: 11, slug: 'nov'} ,{ name: 'FIN.TM.DEC', month: 12, slug: 'dec' }
  ] as Month[];

export interface Month {
  name: string,
  month: number,
  slug: string;
}

export const YEARS = [2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030];