# features-budgetting-budgets

This module is responsible for visualising budget hierarchies and statusses, and for navigating to budget exploration.