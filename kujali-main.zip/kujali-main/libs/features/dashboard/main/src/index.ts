export * from './lib/dashboard.module';

export * from './lib/pages/dashboard/dashboard.page';
