# elements-base-firebase

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test elements-base-firebase` to execute the unit tests.
