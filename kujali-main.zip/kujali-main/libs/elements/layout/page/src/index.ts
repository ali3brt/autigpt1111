export * from './lib/components/sidenav-container/nav-wrapper.component';
export * from './lib/components/app-page/page.component';
export * from './lib/components/app-navbar-side/navbar-side.component';

export * from './lib/ital-page.module';
