export * from './lib/config.interface';
export * from './lib/version-config.interface';
