# finance-planning-time

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test finance-planning-time` to execute the unit tests via [Jest](https://jestjs.io).

## Running lint

Run `nx lint finance-planning-time` to execute the lint via [ESLint](https://eslint.org/).
