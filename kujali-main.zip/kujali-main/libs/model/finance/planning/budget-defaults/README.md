# finance-planning-budget-defaults

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test finance-planning-budget-defaults` to execute the unit tests via [Jest](https://jestjs.io).

## Running lint

Run `nx lint finance-planning-budget-defaults` to execute the lint via [ESLint](https://eslint.org/).
