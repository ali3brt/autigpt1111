
/**
 * Status of the budget explorer page.
 *  Can be view-only or edit.
 */
export enum BudgetExplorerStatus
{
  
}