---
name: Feature
about: Use for elewa only. Description of feature or task requests
title: ''
labels: ''
assignees: ''

---

** Feature name

Feature summary description and main user story.

** Description

Describe behaviour of the feature here

***Prototypes/designs
Add drawings of prototypes or high-fidelity designs

** Implementation details

*** Technical description

*** Acceptance criteria

- [ ] Create a list of acceptance criteria the app should adhere to
- [ ] Assign labels where necessary
