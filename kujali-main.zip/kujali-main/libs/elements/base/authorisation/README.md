# elements-base-authorisation

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test elements-base-authorisation` to execute the unit tests.
