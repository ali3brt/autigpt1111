import { Roles } from '@iote/bricks';

export interface KuUserRoles extends Roles 
{ 
  admin: boolean;
}
