
export interface Address
{
  postalAddress: string;

  physicalAddress: string;

  country: string;

  county: string;
}
