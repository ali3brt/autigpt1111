# features-budgetting-budget-explorer

This module is responsible for editing and visualising a single budget (stub?).